import React from "react";
import { useState } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
// import "https://unpkg.com/mustard-ui@latest/dist/css/mustard-ui.min.css";
import {Table} from 'react-bootstrap';

const TableName = (props) => {
  const [value, setValue] = useState('');
  // const filteredTable = document.getElementById('items tr').filter(country => {
  //   return country.name.toLowerCase().includes(value.toLowerCase())
  // })
    return(
      <div>
        <div className="search-input">
          <input 
          type="text" 
          className="form-control" 
          id="search-text" 
          placeholder="Enter a value..."
          onChange={(event) => setValue(event.target.value)}>
          </input>
        </div>
      <center>
        <Table className="table table-hover table-dark" id="info-table">
        <thead>
          <tr>
            <th>Наименование</th>
            <th>Площадь</th>
            <th>Комментарий</th>
          </tr>
        </thead>
        <tbody id="items">
              {/* {props.data.map(item => (
                <tr key={item}>
                  <td>{}</td>
                  <td></td>
                  <td></td>

                </tr>
              ))} */}
          <tr>
            <td>Russia</td>
            <td>Moscow</td>
            <td>NaN</td>
          </tr>
          <tr>
            <td>Ukraina</td>
            <td>YFIJKV</td>
            <td>UGIUGFF</td>
          </tr>
          <tr>
            <td>UTDKTIIFKYI</td>
            <td>RSYXYLFYLI</td>
            <td>YDTDTYOYDTYTDYT</td>
          </tr>
          <tr>
            <td>UYYOFIOHO</td>
            <td>IYFLFKIYFKITYR</td>
            <td>TEYJFYFHJBBJP</td>
          </tr>
        </tbody>
      </Table>
      </center>
      </div>
    );
}
export default TableName;