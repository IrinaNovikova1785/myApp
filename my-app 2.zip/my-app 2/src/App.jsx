import React, {useEffect} from "react";
import { useDispatch } from "react-redux";


function App() {
  const dispatch = useDispatch();
  return (
    <div>

    </div>
  );
}

export default App;
