import "../vakata-jstree-7a03954/dist/themes/default/style.min.css";
import "../vakata-jstree-7a03954/dist/jstree.min.js"
import "jquery/dist/jquery.min.js";
import $ from "jquery";

const DataFromLS = () => {
    let JSONkv = Object.entries(localStorage),
        c = 0,
        country = [],
        r = 0,
        respublic = [],
        t = 0,
        town = [];
    // function Multy(Arr) {
    //         let parentID = JSON.parse(Arr[i][1]);
    //         let ID = JSON.parse(Arr[i][0]);
    // }

    
    for (let i = 0; i < JSONkv.length; i++) {
        let parentIDnull = JSON.parse(JSONkv[i][1]);
        let IDCountry = JSON.parse(JSONkv[i][0]);
        if (parentIDnull[0] == null) {
            country = [parentIDnull[1], IDCountry];
            let a = IDCountry;

            let node = new TreeNode('a');
            let bNode = new TreeNode(country)
            node.setChildren(bNode);
            //console.log(node);
            
            for (let j = 0; j < JSONkv.length; j++) {
                let parentID = JSON.parse(JSONkv[j][1]);
                let IDRespublic = JSON.parse(JSONkv[j][0]);
                if (a == parentID[0]) {
                    respublic[r] = [parentID[1], IDRespublic];
                    r++;
                    let b = IDRespublic;
                    //console.log(respublic);
                    for (let k = 0; k < JSONkv.length; k++) {
                        let parentID = JSON.parse(JSONkv[k][1]);
                        let IDTown = JSON.parse(JSONkv[k][0]);
                        if (b == parentID[0]) {
                            town[t] = [parentID[1], IDTown];
                            t++;
                            //console.log(town);

                        }
                    }
                }
            }
            
        }
        
    }



  
    // $(function () {
    //     $('#tree').jstree();
    // })
   //$('#tree').create_node("#Little","mur");
    
    return(
        <div id="tree">
        <ul>
            <li>Go</li>
            <li>Little</li>
            <li>Rockstar</li>
        </ul>
    </div>
    );
}


export default DataFromLS;