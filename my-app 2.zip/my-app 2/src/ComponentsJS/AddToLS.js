import arr1 from '../areas.js';

const AddToLS = () =>{  
    //Object.keys(prop).forEach(key => localStorage.setItem(key, prop[key]));

    function LevelThree(massiv) {
        let value = [massiv.parent_id, massiv.name];
        let key = [massiv.id];
        localStorage.setItem(key, JSON.stringify(value));
        // console.log(value);
        // console.log(key);
    }

    for (let i = 0; i < arr1.length; i++) {
        LevelThree(arr1[i]);
        for (let j = 0; j < arr1[i].areas.length; j++) {
            LevelThree(arr1[i].areas[j])
            for (let k = 0; k < arr1[i].areas[j].areas.length; k++) {
                LevelThree(arr1[i].areas[j].areas[k])
            }
        }
    }
    

    
}
export default AddToLS;