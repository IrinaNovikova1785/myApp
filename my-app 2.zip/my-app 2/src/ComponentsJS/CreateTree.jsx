import "../vakata-jstree-7a03954/dist/themes/default/style.min.css";
import "../vakata-jstree-7a03954/dist/jstree.min.js"
import "jquery/dist/jquery.min.js";
import DataFromLS from "./DataFromLS";

const Tree = () => {
    // class TreeNode {
    //     constructor(value) {
    //         this.parent = this.parent;
    //         this.value = value[0];
    //         this.id = value[1];
    //         this.children = [];
    //     }

    //     setChildren(node) {
    //         if (this.children) {
    //             this.children.parent = null;
    //         }
    //         if (node) {
    //             this.children = node;
    //             this.children.parent = this;
    //         }
    //     }
    // }

    // function Node(data) {
    //     this.data = data[0];
    //     this.id = data[1];
    //     this.parent = null;
    //     this.children = [];
    // }

    // function Tree(data) {
    //     let node = new Node(data);
    //     this._root = node;
    // }

    // Tree.prototype.traverseDF = function (callback) {
    //     (function recurse(currentNode) {
    //         let length = currentNode.children.length;
    //         for (let i = 0; i < length; i++) {
    //             recurse(currentNode.children[i]);
    //         }
    //         callback(currentNode);
    //     })(this._root);
    // }

    // // Tree.prototype.traverseBF = function (callback) {
    // //     let queue = new Queue();
    // //     queue.enqueue(this._root);
    // //     let currentNode = queue.dequeue();
    // //     while (currentNode) {
    // //         for (let i = 0, length = currentNode.children.length; i < length; i++) {
    // //             queue.enqueue(currentNode.children[i]);
    // //         }
    // //         callback(currentNode);
    // //         currentNode = queue.dequeue();
    // //     }
    // // };

    // Tree.prototype.contains = function(callback, traversal) {
    //     traversal.call(this, callback);
    // };

    // Tree.prototype.add = function (data, toData, traversal) {
    //     let child = new Node(data),
    //         parent = null,
    //         callback = function (node) {
    //             if (node.data == toData) {
    //                 parent = node;
    //             }
    //         };

    //     this.contains(callback, traversal);

    //     if(parent) {
    //         parent.children.push(child);
    //         child.parent = parent;
    //     } else {
    //         throw new Error('Cannot add node to a non-existent parent.');
    //     }
    // };

    // Tree.prototype.remove = function (data, fromData, traversal) {
    //     let tree = this,
    //         parent = null,
    //         childRemove = null,
    //         index;

    //     let callback = function (node) {
    //         if (node.data === fromData) {
    //             parent = node;
    //         }
    //     };
    //     this.contains(callback, traversal);
    //     if (parent) {
    //         index = findIdex(parent.children, data);

    //         if (index === undefined) {
    //             throw new Error('Node to remove does not exist.');
    //         } else {
    //             childRemove = parent.children.splice(index, 1)
    //         }
    //     } else {
    //         throw new Error('Parent does not exist.');
    //     }
    //     return childRemove;
    // };

    // function findIdex(arr, data) {
    //     let index;

    //     for(let i = 0; i < arr.length; i++) {
    //         if(arr[i].data === data) {
    //             index = i;
    //         }
    //     }
    //     return index;
    // }

    // // let tree = new Tree (JSONkv[0][0]);
    // // console.log(tree);

    // // for (let i = 0; i < rrr.length; i++){
    // //     let row = document.createElement('tr'); // создаем строку таблицы
    // //     row.innerHTML = `
    // //         <td>${rrr[i][0]}</td>
    // //     `
    // //     document.querySelector('.userdata').appendChild(row);



    // //     // tr += '<td>' + section.id[i] + '</td>'; // добавляем столбцы в строку
    // //     // tr += '<td>' + section.name[i] + '</td>';
    // //     // tr += '<td>' + section.sum[i] + '</td>';
    // //     // tr += '</td>';
    // //     //$('#painting > tbody:last-child').append(tr); // добавляем полученную строку в дом
    // // }
    return(
        <div id="tree">
            <ul>
                <li>${co}</li>
            </ul>
        </div>
    );
}
export default Tree;